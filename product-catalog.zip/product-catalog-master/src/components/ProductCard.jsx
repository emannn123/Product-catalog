function ProductCard({ product }) {
  return (
    <div className="card">
      <img
        src={product.thumbnail}
        alt={product.title}
      />

      <h2>{product.title}</h2>

      <p className="price">${product.price}</p>

      <p>{product.description}</p>

      <p>
        <strong>Category:</strong> {product.category}
      </p>

      <p>
        <strong>ID:</strong> {product.id}
      </p>
    </div>
  );
}

export default ProductCard;