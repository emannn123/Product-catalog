import "./App.css";
import ProductCard from "./components/ProductCard";
import ProductForm from "./components/ProductForm";
import useProducts from "./hooks/useProducts";

function App() {
  const { products, loading, addProduct } = useProducts();

  return (
    <div className="container">
      <h1>🛍 Product Catalog</h1>

      <ProductForm onAddProduct={addProduct} />

      {loading ? (
        <h2 className="loading">Loading Products...</h2>
      ) : (
        <div className="product-grid">
          {products.map((product) => (
            <ProductCard
              key={product.id}
              product={product}
            />
          ))}
        </div>
      )}
    </div>
  );
}

export default App;